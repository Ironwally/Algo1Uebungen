import de.hska.iwi.ads.solution.search.BinarySearch;

public class Main {
    public static void main(String[] args) {
    }
}